export default function Experience({ experience }) {
  return (
    <section className="section section-soft" id="experience">
      <div className="container">
        <div className="section-heading-row">
          <div>
            <p className="section-kicker">Case Study Style</p>
            <h2 className="section-title">{experience.heading}</h2>
          </div>
          <p className="section-intro narrow-copy">{experience.intro}</p>
        </div>

        <div className="experience-grid">
          {experience.cards.map((card) => (
            <article key={card.title} className="experience-card">
              <h3>{card.title}</h3>
              <p>{card.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
