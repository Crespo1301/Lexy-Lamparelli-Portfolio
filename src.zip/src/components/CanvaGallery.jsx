export default function CanvaGallery({ items }) {
  return (
    <section className="section section-soft" id="canva-work">
      <div className="container">
        <div className="section-heading-row">
          <div>
            <p className="section-kicker">Featured Section</p>
            <h2 className="section-title">Canva Work</h2>
          </div>
          <p className="section-intro narrow-copy">
            This area is set up as a visual-first grid so you can drop in her best Canva pieces without changing the whole layout.
          </p>
        </div>

        <div className="gallery-grid">
          {items.map((item) => (
            <article key={item.title} className="project-card">
              <div className="project-image-placeholder">
                <span>{item.imageLabel}</span>
              </div>
              <div className="project-body">
                <p className="tag">{item.category}</p>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
