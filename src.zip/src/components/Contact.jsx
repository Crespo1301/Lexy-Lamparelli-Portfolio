export default function Contact({ contact, socialLinks }) {
  return (
    <section className="section" id="contact">
      <div className="container">
        <div className="contact-panel">
          <div className="stack-md">
            <p className="section-kicker">Contact</p>
            <h2 className="section-title">{contact.heading}</h2>
            <p className="narrow-copy">{contact.text}</p>
          </div>

          <div className="contact-actions">
            <a className="button button-primary" href={`mailto:${contact.email}`}>
              {contact.email}
            </a>
            <div className="social-pills social-pills-wrap">
              {socialLinks.map((link) => (
                <a key={link.label} className="social-pill" href={link.href} target="_blank" rel="noreferrer">
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
