export default function Navbar({ navItems }) {
  return (
    <header className="navbar-wrap">
      <div className="container navbar">
        <a className="brand" href="#top">
          <span className="brand-mark">LL</span>
          <span className="brand-text">Lexy Lamparelli</span>
        </a>

        <nav className="nav-links" aria-label="Primary navigation">
          {navItems.map((item) => (
            <a key={item.href} href={item.href}>
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  )
}
