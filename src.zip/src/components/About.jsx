export default function About({ about }) {
  return (
    <section className="section" id="about">
      <div className="container two-column-section">
        <div>
          <p className="section-kicker">Introduction</p>
          <h2 className="section-title">{about.heading}</h2>
        </div>

        <div className="section-content stack-lg">
          {about.text.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}

          <div className="highlight-list">
            {about.highlights.map((item) => (
              <div key={item} className="highlight-item">
                <span className="highlight-dot" />
                <p>{item}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
