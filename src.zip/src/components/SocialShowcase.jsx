export default function SocialShowcase({ items }) {
  return (
    <section className="section" id="social-media">
      <div className="container">
        <div className="section-heading-row">
          <div>
            <p className="section-kicker">Content Showcase</p>
            <h2 className="section-title">Social Media Work</h2>
          </div>
          <p className="section-intro narrow-copy">
            Use these cards for TikTok embeds, reel thumbnails, campaign summaries, or platform-specific social proof.
          </p>
        </div>

        <div className="social-grid">
          {items.map((item) => (
            <article key={item.title} className="social-card">
              <div className="embed-placeholder">
                <span>{item.platform}</span>
                <strong>Preview / embed area</strong>
              </div>
              <div className="social-card-body">
                <div className="social-card-topline">
                  <p className="tag">{item.platform}</p>
                  <p className="metric">{item.metric}</p>
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
                <a href={item.link} target="_blank" rel="noreferrer">
                  Add live link →
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
