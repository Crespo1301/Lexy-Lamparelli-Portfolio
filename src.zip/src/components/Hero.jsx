export default function Hero({ hero, socialLinks }) {
  return (
    <section className="hero-section" id="top">
      <div className="container hero-grid">
        <div className="hero-copy">
          <p className="eyebrow">{hero.eyebrow}</p>
          <h1>{hero.name}</h1>
          <h2>{hero.title}</h2>
          <p className="hero-description">{hero.description}</p>

          <div className="hero-actions">
            <a className="button button-primary" href={hero.primaryCta.href}>
              {hero.primaryCta.label}
            </a>
            <a className="button button-secondary" href={hero.secondaryCta.href}>
              {hero.secondaryCta.label}
            </a>
          </div>

          <div className="social-pills">
            {socialLinks.map((link) => (
              <a key={link.label} className="social-pill" href={link.href} target="_blank" rel="noreferrer">
                {link.label}
              </a>
            ))}
          </div>
        </div>

        <div className="hero-panel">
          <div className="hero-card hero-card-accent">
            <span>Featured Focus</span>
            <strong>Canva design, social media visuals, and short-form content.</strong>
          </div>

          <div className="hero-card-grid">
            {hero.stats.map((item) => (
              <article key={item.label} className="hero-card stat-card">
                <strong>{item.value}</strong>
                <span>{item.label}</span>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
