export const siteContent = {
  navItems: [
    { label: 'About', href: '#about' },
    { label: 'Canva Work', href: '#canva-work' },
    { label: 'Social Media', href: '#social-media' },
    { label: 'Experience', href: '#experience' },
    { label: 'Contact', href: '#contact' },
  ],
  hero: {
    name: 'Lexy Lamparelli',
    eyebrow: 'Creative Portfolio',
    title: 'Canva Designer & Social Media Creative',
    description:
      'I create engaging visual content, platform-ready campaigns, and social media work designed to help brands connect and stand out.',
    primaryCta: { label: 'View My Work', href: '#canva-work' },
    secondaryCta: { label: 'Get In Touch', href: '#contact' },
    stats: [
      { value: '3+', label: 'Featured content categories' },
      { value: '100%', label: 'Mobile-friendly portfolio layout' },
      { value: '1', label: 'Single-page experience' },
    ],
  },
  about: {
    heading: 'About Me',
    text: [
      'I focus on visual storytelling through Canva design, short-form content, and social media presentation. My work blends creativity with clear brand communication so every post, graphic, and campaign feels polished and intentional.',
      'This portfolio is designed to highlight the range of my content work—from static graphics and promotional pieces to social content and campaign support from previous roles.',
    ],
    highlights: [
      'Canva graphics & branded layouts',
      'TikTok and short-form social content',
      'Social media support for previous brand work',
    ],
  },
  canvaProjects: [
    {
      title: 'Brand Promo Graphics',
      category: 'Canva Design',
      description: 'A showcase space for polished branded graphics, promotional layouts, and social-first visual design work.',
      imageLabel: 'Drop screenshot or mockup here',
    },
    {
      title: 'Event & Campaign Assets',
      category: 'Canva Design',
      description: 'Use this card for flyers, campaign visuals, launch graphics, or event-specific design materials.',
      imageLabel: 'Replace with portfolio image',
    },
    {
      title: 'Content Templates',
      category: 'Canva Design',
      description: 'Highlight reusable content systems, feed templates, story sets, or cohesive branded design packages.',
      imageLabel: 'Replace with portfolio image',
    },
    {
      title: 'Creative Social Visuals',
      category: 'Canva Design',
      description: 'A good fit for eye-catching post graphics, quote cards, infographics, and styled content pieces.',
      imageLabel: 'Replace with portfolio image',
    },
  ],
  socialProjects: [
    {
      title: 'TikTok Content Highlights',
      platform: 'TikTok',
      description: 'Embed top TikToks here or replace this card with thumbnails that link to live content.',
      metric: 'Add views / engagement',
      link: '#',
    },
    {
      title: 'Instagram / Reels Work',
      platform: 'Instagram',
      description: 'Use this space for reel previews, content strategy support, and short-form storytelling examples.',
      metric: 'Add reach / saves / shares',
      link: '#',
    },
    {
      title: 'Content Planning & Execution',
      platform: 'Social Strategy',
      description: 'Perfect for explaining your role in ideation, scheduling, branding consistency, and campaign execution.',
      metric: 'Add posting or campaign notes',
      link: '#',
    },
  ],
  experience: {
    heading: 'Previous Social Media Work',
    intro:
      'Use this section to show the social media work you completed for your last job. It works best with a short overview, a few visual examples, and 2–4 bullet points explaining your impact.',
    cards: [
      {
        title: 'Role Snapshot',
        text: 'Add your previous title, company name, and a concise summary of the type of content or brand support you handled.',
      },
      {
        title: 'Key Contributions',
        text: 'Describe things like managing posts, creating graphics, supporting campaigns, filming content, or coordinating social presence.',
      },
      {
        title: 'Results & Wins',
        text: 'If available, add measurable outcomes such as follower growth, engagement, campaign performance, or consistency improvements.',
      },
    ],
  },
  contact: {
    heading: 'Let’s Work Together',
    text:
      'Interested in content creation, branded visuals, or social media support? Reach out and let’s talk about your next project.',
    email: 'hello@example.com',
  },
  socialLinks: [
    { label: 'Email', href: 'mailto:hello@example.com' },
    { label: 'Instagram', href: '#' },
    { label: 'TikTok', href: '#' },
    { label: 'LinkedIn', href: '#' },
  ],
}
